#define IDC_STATIC			-1
#define IDD_DIALOG                      101
#define IDC_BUTTON_CHECKPASSWORD        102
#define IDC_EDIT                        1000