#!/bin/bash
fpc -g- -b- -Tdarwin -Sd -Wb Project1.pas
strip ./Project1