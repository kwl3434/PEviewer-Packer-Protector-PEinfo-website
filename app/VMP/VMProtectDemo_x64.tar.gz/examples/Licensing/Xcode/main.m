//
//  main.m
//  VMProtect Licensing Test
//
//  Created by Vitaly on 24/09/13.
//  Copyright (c) 2013 vmpsoft. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
