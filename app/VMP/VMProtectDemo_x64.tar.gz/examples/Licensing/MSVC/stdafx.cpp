#include "stdafx.h"

#pragma comment(lib, "VMProtectSDK32.lib")